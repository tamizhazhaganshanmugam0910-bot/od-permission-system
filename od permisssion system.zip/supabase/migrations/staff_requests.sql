-- ============================================================
-- Migration: Add staff_requests table
-- Run this in your Supabase SQL editor
-- ============================================================

-- 1. Create the staff_requests table
CREATE TABLE IF NOT EXISTS public.staff_requests (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name    TEXT NOT NULL,
  email        TEXT NOT NULL,
  requested_role TEXT NOT NULL CHECK (requested_role IN ('COUNSELLOR', 'CLASS_COORDINATOR', 'HOD')),
  department   TEXT NOT NULL DEFAULT '',
  status       TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  admin_note   TEXT,
  reviewed_by  TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Enable Row-Level Security
ALTER TABLE public.staff_requests ENABLE ROW LEVEL SECURITY;

-- 3. RLS Policies

-- Anyone authenticated can insert their own request
CREATE POLICY "Users can insert own staff request"
  ON public.staff_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- User can read their own request
CREATE POLICY "Users can read own staff request"
  ON public.staff_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Admins can read ALL requests
CREATE POLICY "Admins can read all staff requests"
  ON public.staff_requests FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'ADMIN'
    )
  );

-- Admins can update (approve/reject) requests
CREATE POLICY "Admins can update staff requests"
  ON public.staff_requests FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'ADMIN'
    )
  );

-- 4. Allow admins to update any profile's role
-- (If you already have an update policy, adjust as needed)
CREATE POLICY "Admins can update any profile role"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'ADMIN'
    )
  )
  WITH CHECK (true);

-- 5. Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_staff_requests_status ON public.staff_requests(status);
CREATE INDEX IF NOT EXISTS idx_staff_requests_user_id ON public.staff_requests(user_id);

-- ============================================================
-- HOW TO SET THE FIRST ADMIN:
-- After running this migration, visit /setup in your app.
-- Use the setup key from your .env (VITE_ADMIN_SETUP_KEY).
-- Default key: FIRST_ADMIN_SETUP
-- ============================================================
